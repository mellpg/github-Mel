package Conceito;
// Para não ter duplicidade de código 
public non-sealed class Manager extends Employee {
	// implementação 
	
	private String login;
	
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public double getComission() {
		return comission;
	}

	public void setComission(double comission) {
		this.comission = comission;
	}

	private String password;
	
	private double comission;
	
	
	

}
