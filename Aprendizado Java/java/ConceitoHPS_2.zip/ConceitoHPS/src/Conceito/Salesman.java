package Conceito;

public non-sealed class Salesman extends Employee {
	// Porcentagem do número de vendas 
	// implementação 
	private double PercentPerSold;

	public double getPercentPerSold() {
		return PercentPerSold;
	}

	public void setPercentPerSold(double percentPerSold) {
		PercentPerSold = percentPerSold;
	}
	

}
