package Conceito;

// O Employer é a classe pai/ superclasse
// Os restantes são suas classes filhas
// Estamos definindo heranças
// E o que é Polimorfismo?
// É a capacidade de um método se comportar de maneira
// diferente 
// Ex: Uma casa que tem 3 cachorros
// Todas tem as mesmas características mas
// tem comportamentos / necessidades diferentes.
// Ex: Crédito ou Débito, são diferentes, mas a
// máquina aceita o CARTÃO , serve para os dois
// A máquina é como se fosse um método que aplica 
// pagamento

public class ConceitoHPS {

	public static void main(String[] args) {
		Employee manager = new Manager();
		
		// Se fizermos
		// Employee manager = new Manager();
		// A gente "SETOU" que ele é um gerente
		// você colocou o mais específico para o
		// mais genérico
		// mas o código vai tratar como genérico
		// No nosso código criamos o colaborador
		// temos gerente, vendedor, funcionário...
		// mas para o código isso é indiferente
		// Para o código gerente é gerente, colab = colab etc.
		// Para não ter problemas de restrição
		// definimos como abstrata
		// ela não pode ser instânciada
		
		manager.setName("Pedro");
		//manager.setLogin("Pedro");
		//manager.setPassword("245356");
		
		System.out.println(manager.getName());
		//System.out.println(manager.getLogin());
		//System.out.println(manager.getPassword());
		

	}

}
